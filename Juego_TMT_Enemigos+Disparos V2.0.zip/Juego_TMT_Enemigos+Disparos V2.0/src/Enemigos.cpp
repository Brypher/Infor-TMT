#include "Enemigos.h"


Enemigos::Enemigos()
{

}

Enemigos::~Enemigos()
{

}