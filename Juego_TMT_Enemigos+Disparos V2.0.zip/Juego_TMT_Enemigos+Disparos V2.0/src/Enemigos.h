#pragma once
class Enemigos
{
public:
	//ATRIBUTOS

public:
	//METODOS

};

