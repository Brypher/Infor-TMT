#pragma once
class Bonus
{
public:
	//ATRIBUTOS

public:
	//METODOS

};

