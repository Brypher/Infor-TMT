#pragma once
class Gemas
{
};

